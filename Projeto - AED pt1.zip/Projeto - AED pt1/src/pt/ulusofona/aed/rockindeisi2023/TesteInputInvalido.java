package pt.ulusofona.aed.rockindeisi2023;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.File;

public class TesteInputInvalido {

    @Test
    public void leituraSemErro(){
        File ficheiro = new File("test-files");
        boolean resultadoAtual = Main.loadFiles(ficheiro);

        Assertions.assertTrue(resultadoAtual, "Teste Errado!");
    }

    @Test
    public void leituraComErro(){
        boolean resultadoEsperado = false;
        File ficheiro = new File("test-files");
        boolean resultadoAtual = Main.loadFiles(ficheiro);
        Assertions.assertNotEquals(resultadoEsperado,resultadoAtual, "Teste Errado!");
    }
}