package pt.ulusofona.aed.rockindeisi2023;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    //region Variaveis Globais
    static ArrayList<InputInvalido> input_invalidos = new ArrayList<>();
    static ArrayList<Tema> temas = new ArrayList<>();
    static ArrayList<Artista> artistas = new ArrayList<>();
    //endregion

    //region Funções
    public static boolean validaTemasDetalhes(int posicao) {
        for (int i = posicao; i < temas.size(); i++) {
            if (temas.get(i).duracao == null) {
                temas.remove(i);
                return validaTemasDetalhes(i);
            }
        }
        return true;
    }

    public static boolean validaTemasArtistas(int posicao) {
        for (int i = posicao; i < temas.size(); i++) {
            if (temas.get(i).numArtistas == 0) {
                temas.remove(i);
                return validaTemasArtistas(i);
            }
        }
        return true;
    }
    //endregion

    //region Funções Obrigatórias
    public static boolean loadFiles(File folder) {
        //region Reset Variaveis Globais
        artistas = new ArrayList<>();
        input_invalidos = new ArrayList<>();
        temas = new ArrayList<>();
        //endregion

        //region Ficheiro songs.txt
        File ficheiro = new File(folder, "songs.txt");
        Scanner scanner = null;
        try {
            scanner = new Scanner(ficheiro);
        } catch (FileNotFoundException e) {
            return false;
        }

        //verificador do ficheiro songs
        InputInvalido input_invalido_songs = new InputInvalido("songs.txt", 0, 0, -1);
        while (scanner.hasNext()) {
            String linha = scanner.nextLine();
            String[] partes = linha.split("@");

            //verifica se a linha está bem
            //caso nao esteja bem acrescenta aos erros
            if (partes.length == 3) {
                //verifica se o id da linha a ser lida é duplicado ou não
                boolean found = false;
                for (Tema tema : temas) {
                    if (tema.id.equals(partes[0].trim())) {
                        //id duplicado
                        found = true;
                        break;
                    }
                }

                //caso não seja duplicado, cria um tema
                //caso seja duplicado acrescenta aos erros
                if (!found) {
                    input_invalido_songs.linhasOK++;
                    //id, titulo, ano
                    Tema tema = new Tema(partes[0].trim(), partes[1].trim(), Integer.parseInt(partes[2].trim()));
                    temas.add(tema);
                } else {
                    if (input_invalido_songs.primeiraLinhaNOK == -1) {
                        input_invalido_songs.primeiraLinhaNOK = input_invalido_songs.linhasOK + 1;
                    }

                    input_invalido_songs.linhasNOK++;
                }
            } else {
                if (input_invalido_songs.primeiraLinhaNOK == -1) {
                    input_invalido_songs.primeiraLinhaNOK = input_invalido_songs.linhasOK + 1;
                }

                input_invalido_songs.linhasNOK++;
            }
        }
        //endregion

        //region Ficheiro song_details.txt
        ficheiro = new File(folder, "song_details.txt");
        try {
            scanner = new Scanner(ficheiro);
        } catch (FileNotFoundException e) {
            return false;
        }

        //verificador do ficheiro song_details
        InputInvalido input_invalido_song_details = new InputInvalido("song_details.txt", 0, 0, -1);
        while (scanner.hasNext()) {
            String linha = scanner.nextLine();
            String[] partes = linha.split("@");

            //verifica se a linha está bem
            //caso nao esteja bem acrescenta aos erros
            if (partes.length == 7) {
                input_invalido_song_details.linhasOK++;

                //procura o id nos temas já criados na leitura do ficheiro anterior
                //se não o encontrar não faz nada
                //se encontrar adiciona a duração e a popularidade ao tema
                for (Tema tema : temas) {
                    if (tema.id.equals(partes[0].trim())) {
                        //a duração vem do ficheiro em ms, por isso temos de passar
                        //para o formato pedido, min:seg
                        int minutos = (int) (Double.parseDouble(partes[1].trim()) / 60000);
                        int segundos = (int) (Double.parseDouble(partes[1].trim()) / 1000) - (minutos * 60);

                        if (segundos < 10) {
                            tema.duracao = minutos + ":0" + segundos;
                        } else {
                            tema.duracao = minutos + ":" + segundos;
                        }

                        tema.popularidade = Integer.parseInt(partes[3].trim());
                        break;
                    }
                }
            } else {
                if (input_invalido_song_details.primeiraLinhaNOK == -1) {
                    input_invalido_song_details.primeiraLinhaNOK = input_invalido_song_details.linhasOK + 1;
                }

                input_invalido_song_details.linhasNOK++;
            }
        }
        //endregion

        //chama a função para eliminar os temas invalidos
        validaTemasDetalhes(0);

        //region Ficheiro song_artists.txt
        ficheiro = new File(folder, "song_artists.txt");
        try {
            scanner = new Scanner(ficheiro);
        } catch (FileNotFoundException e) {
            return false;
        }

        //verificador do ficheiro song_artists
        InputInvalido input_invalido_song_artists = new InputInvalido("song_artists.txt", 0, 0, -1);
        while (scanner.hasNext()) {
            String linha = scanner.nextLine();
            String[] partes = linha.split("@");

            boolean foundSong = false;
            for (Tema tema : temas) {
                if (tema.id.equals(partes[0].trim())) {
                    foundSong = true;
                    break;
                }
            }

            //verifica se a linha está bem
            //caso nao esteja bem acrescenta aos erros
            if (partes.length == 2) {
                input_invalido_song_artists.linhasOK++;

                if (foundSong) {
                    //verifica se o partes[1] começa por " ou por [
                    //fica a false caso começe bem
                    partes[1] = partes[1].trim();
                    ArrayList<String> nomeArtista = new ArrayList<>();
                    if (partes[1].charAt(0) == '"') {
                        //retirar os ""
                        partes[1] = partes[1].replaceAll("\"", "");
                        partes[1] = partes[1].replaceAll("\\[", "");
                        partes[1] = partes[1].replaceAll("]", "");
                        partes[1] = partes[1].replaceAll("'", "");
                        partes[1] = partes[1].trim();

                        String[] partesArtista = partes[1].split(",");
                        for (String s : partesArtista) {
                            nomeArtista.add(s.trim());
                        }
                    } else if (partes[1].charAt(0) == '[') {
                        //retirar os []
                        partes[1] = partes[1].replaceAll("\\[", "");
                        partes[1] = partes[1].replaceAll("]", "");
                        partes[1] = partes[1].replaceAll("'", "");
                        partes[1] = partes[1].trim();

                        String[] partesArtista = partes[1].split(",");
                        if (partesArtista.length == 1) {
                            nomeArtista.add(partesArtista[0].trim());
                        }
                    }

                    //partes[1] começa por " ou por [
                    //adiciona Artista
                    //vai percorrer o array dos nomes dos artistas existentes nesta linha do ficheiro
                    for (String s : nomeArtista) {
                        boolean found = false;
                        for (Artista artista : artistas) {
                            //caso o artista ja exista, vai somar mais 1 no número de músicas do artista
                            if (s.equals(artista.nome)) {
                                artista.numMusicas++;
                                found = true;
                                break;
                            }
                        }

                        //caso ele ainda não exita, vai adicionar à ArrayList
                        if (!found) {
                            //nome, numMusicas
                            Artista artista = new Artista(s, 1);
                            artistas.add(artista);
                        }
                    }

                    //adiciona a um tema existente o tamanho do
                    //array dos nomes, dando assim o número de artistas para aquela música
                    for (Tema tema : temas) {
                        if (tema.id.equals(partes[0].trim())) {
                            tema.numArtistas += nomeArtista.size();
                            break;
                        }
                    }
                }
            } else {
                if (input_invalido_song_artists.primeiraLinhaNOK == -1) {
                    input_invalido_song_artists.primeiraLinhaNOK = input_invalido_song_artists.linhasOK + 1;
                }

                input_invalido_song_artists.linhasNOK++;
            }
        }
        //endregion

        //chama a função para eliminar os temas invalidos
        validaTemasArtistas(0);

        //region add os input_invalidos ao arrayList
        input_invalidos.add(input_invalido_songs);
        input_invalidos.add(input_invalido_song_details);
        input_invalidos.add(input_invalido_song_artists);
        //endregion

        return true;
    }

    public static ArrayList getObjects(TipoEntidade tipo) throws FileNotFoundException {
        switch (tipo) {
            case ARTISTA -> {
                return artistas;
            }
            case TEMA -> {
                return temas;
            }
            case INPUT_INVALIDO -> {
                return input_invalidos;
            }
        }

        return new ArrayList<>();
    }
    //endregion

    public static void main(String[] args) throws FileNotFoundException {
        loadFiles(new File("test-files"));
        System.out.println("\n----------------------------------ARTISTA----------------------------------\n");

        TipoEntidade ent = TipoEntidade.ARTISTA;
        ArrayList arrayList = getObjects(ent);
        for (Object o : arrayList) {
            System.out.println(o);
        }

        System.out.println("\n----------------------------------TEMA----------------------------------\n");

        ent = TipoEntidade.TEMA;
        arrayList = getObjects(ent);
        for (Object o : arrayList) {
            System.out.println(o);
        }

        System.out.println("\n----------------------------------INPUT_INVALIDO----------------------------------\n");

        ent = TipoEntidade.INPUT_INVALIDO;
        arrayList = getObjects(ent);
        for (Object o : arrayList) {
            System.out.println(o);
        }
    }
}
