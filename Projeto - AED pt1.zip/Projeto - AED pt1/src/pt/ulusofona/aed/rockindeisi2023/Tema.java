package pt.ulusofona.aed.rockindeisi2023;

public class Tema {
    String id;
    String titulo;
    int ano;
    String duracao;
    int popularidade;
    int numArtistas;

    Tema(String id, String titulo, int ano) {
        this.id = id;
        this.titulo = titulo;
        this.ano = ano;
    }

    @Override
    public String toString() {
        if (ano <= 1995) {
            return id + " | " + titulo + " | " + ano;
        } else if (ano < 2000) {
            return id + " | " + titulo + " | " + ano + " | " + duracao + " | " + popularidade;
        }
        return id + " | " + titulo + " | " + ano + " | " + duracao + " | " + popularidade + " | " + numArtistas;
    }
}
