package pt.ulusofona.aed.rockindeisi2023;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TesteArtista {

    @Test
    public void toStringArtistaSimples() {
        Artista artistaAtual = new Artista("Alex", 2);
        String resultadoEsperado  = "Artista: [Alex]";

        Assertions.assertEquals(resultadoEsperado, artistaAtual.toString(), "Teste Errado!");
    }

    @Test
    public void toStringArtistaComplexo() {
        Artista artistaAtual = new Artista("Jorge", 2);
        String resultadoEsperado = "Artista: [Jorge] | 2";

        Assertions.assertEquals(resultadoEsperado, artistaAtual.toString(), "Teste Errado!");
    }
}
