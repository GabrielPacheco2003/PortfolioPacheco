package pt.ulusofona.aed.rockindeisi2023;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TesteTema {

    @Test
    public void anterior_1995(){
        Tema temaAtual = new Tema("abcd", "musica", 1994);
        temaAtual.numArtistas = 2;
        temaAtual.duracao = "2:54";
        temaAtual.popularidade = 5;
        String resultadoEsperado = "abcd | musica | 1994";

        Assertions.assertEquals(resultadoEsperado, temaAtual.toString(), "Teste Errado!");
    }

    @Test
    public void anterior_2000(){
        Tema temaAtual = new Tema("abcd", "musica", 1996);
        temaAtual.numArtistas = 2;
        temaAtual.duracao = "2:54";
        temaAtual.popularidade = 5;
        String resultadoEsperado = "abcd | musica | 1996 | 2:54 | 5";


        Assertions.assertEquals(resultadoEsperado, temaAtual.toString(), "Teste Errado!");
    }

    @Test
    public void depois_2000(){
        Tema temaAtual = new Tema("abcd", "musica", 2016);
        temaAtual.numArtistas = 2;
        temaAtual.duracao = "2:54";
        temaAtual.popularidade = 5;
        String resultadoEsperado = "abcd | musica | 2016 | 2:54 | 5 | 2";

        Assertions.assertEquals(resultadoEsperado, temaAtual.toString(), "Teste Errado!");
    }
}
