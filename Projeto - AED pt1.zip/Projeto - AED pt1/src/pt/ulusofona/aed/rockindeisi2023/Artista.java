package pt.ulusofona.aed.rockindeisi2023;

import java.util.ArrayList;

public class Artista {
    String nome;
    int numMusicas;

    Artista(String nome, int numMusicas) {
        this.nome = nome;
        this.numMusicas = numMusicas;
    }

    @Override
    public String toString() {
        if (nome.charAt(0) == 'A' || nome.charAt(0) == 'B' || nome.charAt(0) == 'C' || nome.charAt(0) == 'D') {
            return "Artista: [" + nome + "]";
        }
        return "Artista: [" + nome + "] | " + numMusicas;
    }
}
